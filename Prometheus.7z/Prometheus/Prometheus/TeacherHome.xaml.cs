﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Prometheus_Entity;
using Prometheus_BLL;
using Prometheus_Exeception;

namespace Prometheus
{
    /// <summary>
    /// Interaction logic for TeacherHome.xaml
    /// </summary>
    public partial class TeacherHome : Window
    {
        public TeacherHome()
        {
            InitializeComponent();
            if (((MainWindow)Application.Current.MainWindow).rb_admin.IsChecked == true)
            {
                btn_Admin.Visibility = Visibility.Visible;
            }
            lbl_IDvalue.Content = ((MainWindow)Application.Current.MainWindow).txt_userID.Text;
        }

        private void btn_updateinformation_Click(object sender, RoutedEventArgs e)
        {
            TeacherUpdateInformation updtInfo = new TeacherUpdateInformation(lbl_IDvalue.Content.ToString());
            updtInfo.Show();
        }

        private void btnAdmin_Click(object sender, RoutedEventArgs e)
        {
            AdminPortal adminPortal = new AdminPortal();
            adminPortal.Show();
        }

        private void btn_signOut_Click(object sender, RoutedEventArgs e)
        {
            MainWindow loginScreen = new MainWindow();
            loginScreen.Show();
            this.Close();
        }

        private void btn_assignCourse_Click(object sender, RoutedEventArgs e)
        {
            AssignCourse asgnCourse = new AssignCourse();
            asgnCourse.Show();
        }
    }
}
