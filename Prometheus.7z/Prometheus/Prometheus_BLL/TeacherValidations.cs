﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prometheus_Entity;
using Prometheus_Exeception;
using Prometheus_DAL;
using System.Data;
using System.Data.SqlClient;

namespace Prometheus_BLL
{
    public class TeacherValidations
    {
        TeacherOperations obj = new TeacherOperations();
        public DataTable searchTeacher_BLL(int teacherID)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = obj.searchTeacher_DAL(teacherID);
            }
            catch (PExeception ex) { throw ex; }
            catch (SqlException ex) { throw ex; }
            catch (Exception ex) { throw ex; }
            return dt;
        }
        public int updateTeacher_BLL(Teacher teacher)
        {
            int rowsaffected = 0;
            try
            {
                rowsaffected = obj.updateTeacher_DAL(teacher);
            }
            catch (PExeception ex) { throw ex; }
            catch (SqlException ex) { throw ex; }
            catch (Exception ex) { throw ex; }
            return rowsaffected;
        }
    }
}
