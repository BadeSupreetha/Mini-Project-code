﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prometheus_Entity;
using Prometheus_Exeception;
using Prometheus_DAL;

namespace Prometheus_BLL
{
    class HomeworkValidations
    {
    }
}
