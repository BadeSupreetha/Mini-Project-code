﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prometheus_Entity;
using Prometheus_Exeception;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace Prometheus_DAL
{
    public class LoginOperations
    {
        public bool IsLogin_DAL(int ID,string password,int selection)
        {
            SqlConnection empConnObj = null;
            SqlCommand empCommand = null;
            SqlDataReader empReader = null;
            bool isValid = false;
            try
            {
                string empConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
                empConnObj = new SqlConnection();
                empConnObj.ConnectionString = empConnStr;
                if (selection == 1)
                {
                    empCommand = new SqlCommand("Group1.usp_LoginAdminTeacher", empConnObj);
                    empCommand.CommandType = CommandType.StoredProcedure;
                    empCommand.Parameters.AddWithValue("@Tid", ID);
                    empCommand.Parameters.AddWithValue("@password", password);
                    empCommand.Parameters.AddWithValue("@IsAdm", true);
                    empConnObj.Open();
                    empReader = empCommand.ExecuteReader();
                    if (empReader.HasRows)
                    {
                        isValid = true;
                    }
                }
                else if (selection == 2)
                {
                    empCommand = new SqlCommand("Group1.usp_LoginAdminTeacher", empConnObj);
                    empCommand.CommandType = CommandType.StoredProcedure;
                    empCommand.Parameters.AddWithValue("@Tid",ID);
                    empCommand.Parameters.AddWithValue("@password",password);
                    empCommand.Parameters.AddWithValue("@IsAdm",false);
                    empConnObj.Open();
                    empReader = empCommand.ExecuteReader();
                    if (empReader.HasRows)
                    {
                        isValid = true;
                    }
                }
                else
                {
                    empCommand = new SqlCommand("Group1.usp_LoginStudent", empConnObj);
                    empConnObj.Open();
                    empReader = empCommand.ExecuteReader();
                    if (empReader.HasRows)
                    {
                        isValid = true;
                    }
                }
            }
            catch(SqlException)
            {
                throw;
            }
            catch(Exception)
            {
                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open)
                    empConnObj.Close();
            }
            return isValid; 
        }
    }
}
